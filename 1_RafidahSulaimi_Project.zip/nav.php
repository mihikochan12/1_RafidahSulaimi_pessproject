<h1>Police Emergency Service System</h1>
<nav id="HeaderStyle">
	<ul>
	<li><a href="logcall.php"><span>Log Call</span></a></li>
	<li><a href="update.php"><span>Update</span></a></li>
	<li><a href="#"><span>Report</span></a></li>
	<li><a href="#"><span>History</span></a></li>
	</ul>
</nav>